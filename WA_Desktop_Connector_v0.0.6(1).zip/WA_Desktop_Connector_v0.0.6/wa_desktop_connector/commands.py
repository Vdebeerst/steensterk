from __future__ import annotations

import os
import sys
from pathlib import Path
from typing import Any

from .exceptions import CommandError
from .odoo_client import download_document
from .protocol import ProtocolRequest


def _string_parameter(request: ProtocolRequest, name: str) -> str | None:
    value = request.parameters.get(name)
    if value is None:
        return None
    if isinstance(value, list):
        if len(value) != 1:
            raise CommandError(f"Parameter '{name}' may only occur once.")
        value = value[0]
    value = str(value).strip()
    return value or None


def _open_local_file(path: Path) -> None:
    if sys.platform == "win32":
        os.startfile(path)  # type: ignore[attr-defined]
        return
    raise CommandError("Opening downloaded files is currently supported only on Windows.")


def execute_command(request: ProtocolRequest, *, open_file: bool = True) -> dict[str, Any]:
    if request.action != "open":
        raise CommandError(f"Unsupported WA action: {request.action}")

    download_url = _string_parameter(request, "download_url")
    if not download_url:
        # Backwards-compatible preview mode used while testing Odoo URL generation.
        return {
            "status": "parsed",
            "action": request.action,
            "path": request.path,
            "parameters": request.parameters,
            "message": "No download_url supplied; request was parsed but no file was downloaded.",
        }

    target = download_document(
        download_url,
        filename=_string_parameter(request, "filename"),
        bearer_token=_string_parameter(request, "access_token"),
    )
    if open_file:
        _open_local_file(target)

    return {
        "status": "opened" if open_file else "downloaded",
        "action": request.action,
        "file": str(target),
    }
