from __future__ import annotations

import mimetypes
import re
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import unquote, urlparse
from urllib.request import Request, urlopen

from .config import app_data_dir
from .exceptions import DownloadError

_SAFE_FILENAME = re.compile(r"[^A-Za-z0-9._() -]+")


def download_dir() -> Path:
    path = app_data_dir() / "downloads"
    path.mkdir(parents=True, exist_ok=True)
    return path


def _safe_filename(value: str) -> str:
    name = Path(unquote(value)).name.strip() or "document"
    name = _SAFE_FILENAME.sub("_", name)
    return name[:180] or "document"


def _filename_from_headers(headers, fallback_url: str, requested: str | None) -> str:
    if requested:
        return _safe_filename(requested)

    disposition = headers.get("Content-Disposition", "")
    match = re.search(r"filename\*?=(?:UTF-8''|\")?([^\";]+)", disposition, re.I)
    if match:
        return _safe_filename(match.group(1))

    url_name = Path(urlparse(fallback_url).path).name
    if url_name:
        return _safe_filename(url_name)

    content_type = headers.get_content_type() if hasattr(headers, "get_content_type") else ""
    extension = mimetypes.guess_extension(content_type or "") or ""
    return f"document{extension}"


def download_document(
    url: str,
    *,
    filename: str | None = None,
    bearer_token: str | None = None,
    timeout: int = 60,
) -> Path:
    parsed = urlparse(url)
    if parsed.scheme.lower() != "https":
        raise DownloadError("For safety, document downloads require an https:// URL.")
    if not parsed.hostname:
        raise DownloadError("The download URL does not contain a valid host.")

    headers = {"User-Agent": "WA-Desktop-Connector/0.0.6"}
    if bearer_token:
        headers["Authorization"] = f"Bearer {bearer_token}"

    request = Request(url, headers=headers, method="GET")
    try:
        with urlopen(request, timeout=timeout) as response:
            target_name = _filename_from_headers(response.headers, url, filename)
            target = download_dir() / target_name
            temporary = target.with_suffix(target.suffix + ".part")
            with temporary.open("wb") as stream:
                while chunk := response.read(1024 * 1024):
                    stream.write(chunk)
            temporary.replace(target)
            return target
    except HTTPError as exc:
        raise DownloadError(f"Download failed with HTTP status {exc.code}.") from exc
    except URLError as exc:
        raise DownloadError(f"Could not reach the document server: {exc.reason}") from exc
    except OSError as exc:
        raise DownloadError(f"Could not save the downloaded document: {exc}") from exc
