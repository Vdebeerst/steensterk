class ConnectorError(RuntimeError):
    """Base error raised for expected connector failures."""


class CommandError(ConnectorError):
    """Raised when a protocol command is unsupported or invalid."""


class DownloadError(ConnectorError):
    """Raised when a remote document cannot be downloaded safely."""
