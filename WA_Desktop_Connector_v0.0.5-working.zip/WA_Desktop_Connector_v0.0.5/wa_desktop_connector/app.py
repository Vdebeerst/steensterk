from __future__ import annotations

import argparse
import json
import sys

from .config import ensure_config
from .logging_setup import configure_logging, log_path
from .protocol import ProtocolError, parse_protocol_url
from .registry import install_protocol, protocol_status
from .version import VERSION


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="WA Desktop Connector")
    parser.add_argument("--install-protocol", action="store_true")
    parser.add_argument("--protocol-status", action="store_true")
    parser.add_argument("--show-log", action="store_true")
    parser.add_argument("url", nargs="?")
    return parser


def main() -> int:
    ensure_config()
    logger = configure_logging()
    args = build_parser().parse_args()

    try:
        if args.install_protocol:
            command = install_protocol()
            logger.info("WA protocol installed: %s", command)
            print("Protocol installed.")
            print(command)
            return 0

        if args.protocol_status:
            command = protocol_status()
            if command:
                print("Registered:")
                print(command)
                return 0
            print("Protocol not installed.")
            return 1

        if args.show_log:
            print(log_path())
            return 0

        if args.url:
            request = parse_protocol_url(args.url)
            data = {
                "action": request.action,
                "path": request.path,
                "parameters": request.parameters,
            }
            logger.info("Protocol request received: %s", json.dumps(data, ensure_ascii=False))
            print(json.dumps(data, indent=2, ensure_ascii=False))
            return 0

        print(f"WA Desktop Connector {VERSION}")
        print("Run with --install-protocol to register wa:// in Windows.")
        return 0

    except (ProtocolError, RuntimeError, OSError) as exc:
        logger.exception("Connector error: %s", exc)
        print(f"Error: {exc}", file=sys.stderr)
        return 1
