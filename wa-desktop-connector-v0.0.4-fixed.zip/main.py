from wa_desktop_connector.app import main

if __name__=="__main__":
    main()
