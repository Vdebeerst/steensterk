# WA Desktop Connector v0.0.5

This version keeps the working Windows `wa://` protocol registration from v0.0.4 and adds URL parsing, configuration and file logging.

## Test

```cmd
python main.py
python main.py --install-protocol
python main.py --protocol-status
python main.py "wa://open?document_id=123&database=demo"
python main.py --show-log
start "" "wa://open?document_id=123&database=demo"
```

The configuration and log files are stored below `%APPDATA%\WA` on Windows.
