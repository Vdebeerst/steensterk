
import argparse,sys
from pathlib import Path
import winreg

def install():
    key=r"Software\Classes\wa"
    with winreg.CreateKey(winreg.HKEY_CURRENT_USER,key) as k:
        winreg.SetValueEx(k,"",0,winreg.REG_SZ,"URL:WA Protocol")
        winreg.SetValueEx(k,"URL Protocol",0,winreg.REG_SZ,"")
    cmd=f'"{Path(sys.executable)}" "{Path(__file__).resolve().parent.parent/"main.py"}" "%1"'
    with winreg.CreateKey(winreg.HKEY_CURRENT_USER,key+r"\shell\open\command") as k:
        winreg.SetValueEx(k,"",0,winreg.REG_SZ,cmd)
    print("Protocol installed.")
    print(cmd)

def status():
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER,r"Software\Classes\wa\shell\open\command") as k:
            print("Registered:")
            print(winreg.QueryValueEx(k,"")[0])
    except FileNotFoundError:
        print("Protocol not installed.")

def main():
    p=argparse.ArgumentParser()
    p.add_argument("--install-protocol",action="store_true")
    p.add_argument("--protocol-status",action="store_true")
    p.add_argument("url",nargs="?")
    a=p.parse_args()
    if a.install_protocol:
        install(); return
    if a.protocol_status:
        status(); return
    if a.url:
        print("Received:",a.url)
    else:
        print("WA Desktop Connector v0.0.4")
        print("Run with --install-protocol")
