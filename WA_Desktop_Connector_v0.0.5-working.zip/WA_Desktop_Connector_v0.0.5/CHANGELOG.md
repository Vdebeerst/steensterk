# Changelog

## 0.0.5

- Preserved Windows `wa://` protocol installation and status checks.
- Added validation and parsing of `wa://` URLs.
- Added configuration creation under `%APPDATA%\WA`.
- Added rotating file logging.
- Added `--show-log`.
- Added clearer error handling and exit codes.
